"""
URL configuration for the Kidsgift project.

This file routes requests to the Shuup storefront and Django admin.  All
frontend pages are served by Shuup, while `/admin/` provides access to
Django’s admin interface.
"""
from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path('admin/', admin.site.urls),
    # Mount Shuup’s URL configuration at the root
    path('', include('shuup.urls', namespace='shuup')),
]