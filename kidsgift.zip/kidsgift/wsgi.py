"""
WSGI config for Kidsgift project.

This exposes the WSGI callable as a module-level variable named
``application``.  It enables deployment via WSGI servers (Gunicorn,
uWSGI, etc.).
"""
import os
from django.core.wsgi import get_wsgi_application  # type: ignore


os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'kidsgift.settings')

application = get_wsgi_application()