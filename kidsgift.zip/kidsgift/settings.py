"""
Django settings for the Kidsgift project.

This configuration enables Shuup’s marketplace modules to create a
multi‑vendor gift store.  It uses SQLite for local development and sets
Hebrew as the default language.

Sensitive values like SECRET_KEY or database passwords should be
overridden using environment variables in production.
"""
from __future__ import annotations

import os
from pathlib import Path


# Base directory of the project
BASE_DIR = Path(__file__).resolve().parent.parent


# Quick‑start development settings
SECRET_KEY = os.environ.get('DJANGO_SECRET_KEY', 'django-insecure-replace-me')
DEBUG = os.environ.get('DJANGO_DEBUG', 'True') == 'True'
ALLOWED_HOSTS: list[str] = os.environ.get('DJANGO_ALLOWED_HOSTS', '').split() or ['*']


# Application definition
INSTALLED_APPS = [
    # Django core apps
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',

    # Shuup apps – minimal set for a marketplace
    'shuup',
    'shuup.front',
    'shuup.admin',
    'shuup.admin_module_order',
    'shuup.admin_module_front',
    'shuup.admin_module_reports',
    'shuup.admin_module_settings',
    'shuup.admin_module_customer',
    'shuup.admin_module_product',
    'shuup.admin_module_media',
    'shuup.admin_module_tax',
    'shuup.admin_module_shop',
    'shuup.admin_module_payment',
    'shuup.admin_module_discount',
    'shuup.admin_module_shipping',
    'shuup.admin_module_addresses',
    'shuup.admin_module_contact',
    'shuup.admin_module_supplier',
    'shuup.xtheme',
    'shuup.product_imports',
    'shuup.discount',
    'shuup.campaigns',
    'shuup.simple_supplier',  # vendor interface
    'shuup_mp',  # marketplace module
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.locale.LocaleMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'kidsgift.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'templates'],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
                # Shuup context processors
                'shuup.xtheme.context_processors.current_theme',
                'shuup.front.context_processors.global_settings',
                'shuup.front.context_processors.cart',
            ],
        },
    },
]

WSGI_APPLICATION = 'kidsgift.wsgi.application'


# Database
if os.environ.get('DATABASE_URL'):
    # Example: postgres://USER:PASSWORD@HOST:PORT/NAME
    import dj_database_url  # type: ignore
    DATABASES = {
        'default': dj_database_url.parse(os.environ['DATABASE_URL']),
    }
else:
    DATABASES = {
        'default': {
            'ENGINE': 'django.db.backends.sqlite3',
            'NAME': BASE_DIR / 'db.sqlite3',
        }
    }


# Internationalization
LANGUAGE_CODE = 'he'
TIME_ZONE = 'Asia/Hebron'
USE_I18N = True
USE_L10N = True
USE_TZ = True

LOCALE_PATHS = [BASE_DIR / 'locale']


# Static files (CSS, JavaScript, Images)
STATIC_URL = '/static/'
STATIC_ROOT = BASE_DIR / 'staticfiles'
STATICFILES_DIRS = [BASE_DIR / 'static']

MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'


# Default primary key field type
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'


# Shuup specific settings
SHUUP_HOME_URL = '/'
SHUUP_ENABLE_PERFORMANCE_WARNINGS = False

# Commission percentage for donations (5 % by default).
DONATION_PERCENTAGE = float(os.environ.get('DONATION_PERCENTAGE', '5'))