"""Django project package for the Kidsgift marketplace."""
