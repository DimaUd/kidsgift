# Kidsgift Marketplace

This repository contains a minimal Django project configured to run a multi‑vendor
gift marketplace using the open–source Shuup platform.  The goal of the
project is to sell gifts with a portion of each sale donated to a children’s
home.  Vendors can manage their own products and orders, while the site
administrator controls the overall marketplace and donation percentage.

## Features

* **Multi‑vendor support** – powered by Shuup’s marketplace module so each
  vendor can manage their own catalogue, orders and shipping methods.
* **Gift categories** – organise products into categories for easy browsing.
* **Cart and checkout** – customers can add products from multiple vendors to
  one cart; the order is automatically split per vendor and processed
  together.
* **Donation percentage** – a configurable commission so a portion of every
  order is transferred to the children’s home.
* **Coupons** – optional support for discount codes via Shuup’s built‑in
  voucher system.
* **Responsive design** – based on Bootstrap for desktop and mobile.

## Getting Started

1. Ensure you have Python 3.11+ and PostgreSQL installed.  Create and
   activate a virtual environment:

   ```bash
   python3 -m venv venv
   source venv/bin/activate
   ```

2. Install the requirements:

   ```bash
   pip install -r requirements.txt
   ```

3. Initialise the project:

   ```bash
   python manage.py migrate
   python manage.py createsuperuser  # create an admin account
   ```

4. Run the development server:

   ```bash
   python manage.py runserver
   ```

5. Visit `http://127.0.0.1:8000/` in your browser.  Use the admin site at
   `http://127.0.0.1:8000/admin/` to configure your shop, add vendors,
   products and set the donation commission.

## Deployment on a free host

For a free host, [PythonAnywhere](https://www.pythonanywhere.com/) offers a
limited free tier that can run small Django projects.  After creating an
account, upload this repository, install the requirements in a virtualenv
and configure a new web app to point at `kidsgift.wsgi:application`.  See
PythonAnywhere’s documentation for detailed steps.

Alternatively, you can host a static version of the site (without
server‑side checkout) on GitHub Pages or Netlify, but you will lose the
dynamic marketplace functionality and payment processing.

## Note

This project is a skeleton and does not include database dumps, vendor
accounts or production settings.  You must configure payment gateways,
shipping methods and donation logic in the admin interface once the site is
running.  For full documentation of Shuup’s features, refer to the
[official documentation](https://shuup.readthedocs.io/).